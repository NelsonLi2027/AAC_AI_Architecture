"""
Phase 4.2 CRITICAL CONTROL: fixed λ at the magnitude learned modes converge to.

Compares under identical schedule/seed:
  fixed_0.999    — original baseline
  fixed_0.9999   — magnitude global/state converged to
  fixed_0.99999  — even closer to 1
  global         — learned λ (reference)

If fixed_0.9999 ≈ global accuracy, the +13.5pp claim is confounded by
λ magnitude, not adaptivity.
"""
import sys, time, argparse, json, os
import numpy as np
sys.path.insert(0, ".")
from task_mqar import MQARTask
from aac.models_diff import AACDiffPersist, AdamTensor

D_EMB, D_H, N_VOCAB = 32, 32, 64
LR_START, LR_END = 1e-2, 1e-3
BATCH = 8
CKPT = 500

CONFIGS = {
    "fixed_0.999":   dict(persist_mode="fixed", decay_p=0.999),
    "fixed_0.9999":  dict(persist_mode="fixed", decay_p=0.9999),
    "fixed_0.99999": dict(persist_mode="fixed", decay_p=0.99999),
    "global":        dict(persist_mode="global", decay_p=0.999),
}

def lr_schedule(ep, n_total):
    frac = min(1.0, max(0.0, ep / n_total))
    return LR_START + frac * (LR_END - LR_START)

def evaluate(model, n=150, seed=999):
    task = MQARTask(n_vocab=N_VOCAB, seed=seed)
    return float(np.mean([
        model.forward_episode(task.sample_episode(n_pairs=6, n_queries=6, gap_len=(20, 40)), train=False)[1]
        for _ in range(n)
    ]))

def collect_diag(model, n=80, seed=777):
    if hasattr(model, "reset_diag"):
        model.reset_diag()
    task = MQARTask(n_vocab=N_VOCAB, seed=seed)
    key_g, fill_g = [], []
    for _ in range(n):
        ep = task.sample_episode(n_pairs=6, n_queries=6)
        model.forward_episode(ep, train=False)
        gates = getattr(model, "last_gate_values", [])
        oracle = set(kp + 1 for kp in ep["key_positions"] if kp + 1 < len(gates))
        for t, g in enumerate(gates):
            (key_g if t in oracle else fill_g).append(g)
    pk = float(np.mean(key_g)) if key_g else None
    pf = float(np.mean(fill_g)) if fill_g else None
    out = {
        "promote_key": pk, "promote_filler": pf,
        "promote_ratio": (pk / max(pf, 1e-8)) if pk and pf else None,
    }
    if hasattr(model, "summarize_diag"):
        extra = model.summarize_diag()
        for k in ("lambda_mean", "trace_norm", "mem_norm"):
            if extra.get(k) is not None:
                out[k] = extra[k]
    return out

def run_one(name, cfg, seed, duration, ceiling, out_path, all_results):
    task = MQARTask(n_vocab=N_VOCAB, seed=seed)
    model = AACDiffPersist(vocab_size=N_VOCAB, d_emb=D_EMB, d_h=D_H,
                           decay_t=0.9, seed=seed, **cfg)
    model.opt = AdamTensor(model.params, lr=LR_START)
    train_accs, train_losses = [], []
    t0 = time.perf_counter()
    model.opt.zero_grad()
    curve = []
    ep = 0
    while ep < ceiling:
        ep += 1
        model.opt.lr = lr_schedule(ep, duration)
        episode = task.sample_episode(n_pairs=6, n_queries=6)
        loss, acc = model.forward_episode(episode, train=True)
        train_accs.append(acc)
        train_losses.append(loss)
        if ep % BATCH == 0:
            model.opt.step()
            model.opt.zero_grad()
        if ep % CKPT == 0:
            ho = evaluate(model)
            d = collect_diag(model)
            point = {
                "ep": ep, "lr": float(model.opt.lr), "held_out": ho,
                "train_acc_window": float(np.mean(train_accs[-CKPT:])),
                "train_loss_window": float(np.mean(train_losses[-CKPT:])),
                **d,
            }
            curve.append(point)
            ratio = d.get("promote_ratio")
            ratio_s = f"{ratio:.2f}x" if ratio else "n/a"
            lam = d.get("lambda_mean")
            lam_s = f"{lam:.6f}" if lam is not None else "n/a"
            print(
                f"  [{name:14s} seed={seed}] ep {ep:5d}  "
                f"loss={point['train_loss_window']:.3f}  "
                f"held_out={ho:.3f}  λ={lam_s}  ratio={ratio_s}  "
                f"({time.perf_counter()-t0:.0f}s)",
                flush=True,
            )
            partial = dict(config=name, seed=seed, curve=curve,
                           episodes_run=ep, final_acc=ho, final_diag=point)
            others = [r for r in all_results
                      if not (r.get("config") == name and r.get("seed") == seed)]
            with open(out_path, "w") as f:
                json.dump(dict(results=others + [partial], summary={}), f, indent=2)
    return dict(config=name, seed=seed, curve=curve,
                final_acc=curve[-1]["held_out"] if curve else None,
                episodes_run=ep, final_diag=curve[-1] if curve else None)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--configs", nargs="+", default=list(CONFIGS.keys()))
    parser.add_argument("--seeds", nargs="+", type=int, default=[0])
    parser.add_argument("--duration", type=int, default=6000)
    parser.add_argument("--ceiling", type=int, default=8000)
    parser.add_argument("--out", default="run_phase42_lambda_control_results.json")
    args = parser.parse_args()

    out_path = args.out
    all_results = []
    if os.path.exists(out_path):
        try:
            prev = json.load(open(out_path))
            all_results = [r for r in prev.get("results", [])
                           if r.get("episodes_run", 0) >= args.ceiling]
            print(f"Resuming; done: {[(r['config'], r['seed']) for r in all_results]}")
        except Exception:
            pass

    print(f"Configs: {args.configs}")
    print(f"Seeds: {args.seeds}")
    print(f"Schedule: {LR_START}→{LR_END} over {args.duration}, ceiling {args.ceiling}\n")

    for name in args.configs:
        for seed in args.seeds:
            if any(r["config"] == name and r["seed"] == seed for r in all_results):
                print(f"Skipping {name} seed={seed}")
                continue
            print(f"\n{'='*72}\n{name} seed={seed}\n{'='*72}", flush=True)
            r = run_one(name, CONFIGS[name], seed, args.duration, args.ceiling,
                        out_path, all_results)
            all_results = [x for x in all_results
                           if not (x.get("config") == name and x.get("seed") == seed)]
            all_results.append(r)
            print(f"  -> {name} seed={seed} final_acc={r['final_acc']:.3f}", flush=True)
            with open(out_path, "w") as f:
                json.dump(dict(results=all_results, summary={}), f, indent=2)

    print(f"\n{'='*72}\nSUMMARY\n{'='*72}")
    summary = {}
    for name in args.configs:
        finals = [r["final_acc"] for r in all_results if r["config"] == name]
        if not finals:
            continue
        arr = np.array(finals)
        print(f"{name:14s} mean={arr.mean():.3f} std={arr.std():.3f} "
              f"min={arr.min():.3f} max={arr.max():.3f} n={len(arr)}")
        summary[name] = dict(mean=float(arr.mean()), std=float(arr.std()),
                             min=float(arr.min()), max=float(arr.max()),
                             n=len(arr), per_seed={str(r["seed"]): r["final_acc"]
                                                    for r in all_results if r["config"] == name})
    with open(out_path, "w") as f:
        json.dump(dict(args=vars(args), results=all_results, summary=summary), f, indent=2)
    print(f"Saved {out_path}")

if __name__ == "__main__":
    main()
