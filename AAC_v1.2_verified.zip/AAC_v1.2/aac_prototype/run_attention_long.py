"""
AttentionBaseline under Phase 4.1-Long schedule.

Schedule: linear 1e-2 → 1e-3 over 10000 episodes, ceiling 12000.
Same MQAR protocol, convergence criterion as Phase 4.1 long.
Purpose: fair comparison vs AAC utility long-run (70–86%).
"""
import sys, time, argparse, json, os
import numpy as np

sys.path.insert(0, ".")
from task_mqar import MQARTask
from aac.models_diff import AttentionBaseline, AdamTensor

D_EMB, D_H, N_VOCAB = 32, 32, 64
LR_START, LR_END = 1e-2, 1e-3
BATCH = 8
CKPT = 500
DEFAULT_DURATION = 10000
DEFAULT_CEILING = 12000
DEFAULT_SEEDS = [0, 1, 2, 3, 4]
CONVERGE_WINDOW = 4
CONVERGE_TOL_PP = 1.5


def lr_schedule(ep, n_total):
    frac = min(1.0, max(0.0, ep / n_total))
    return LR_START + frac * (LR_END - LR_START)


def evaluate(model, n=150, seed=999):
    task = MQARTask(n_vocab=N_VOCAB, seed=seed)
    return float(np.mean([
        model.forward_episode(
            task.sample_episode(n_pairs=6, n_queries=6, gap_len=(20, 40)),
            train=False)[1]
        for _ in range(n)
    ]))


def check_converged(curve):
    if len(curve) < CONVERGE_WINDOW:
        return False
    last = curve[-CONVERGE_WINDOW:]
    for i in range(1, len(last)):
        if abs(last[i]["held_out"] - last[i - 1]["held_out"]) * 100 > CONVERGE_TOL_PP:
            return False
    return last[-1]["held_out"] >= 0.20


def run_one(seed, duration, ceiling, out_path, all_results):
    task = MQARTask(n_vocab=N_VOCAB, seed=seed)
    model = AttentionBaseline(vocab_size=N_VOCAB, d_emb=D_EMB, d_h=D_H, seed=seed)
    model.opt = AdamTensor(model.params, lr=LR_START)
    train_accs, train_losses = [], []
    t0 = time.perf_counter()
    model.opt.zero_grad()
    curve = []
    converged = False
    ep = 0
    while ep < ceiling:
        ep += 1
        model.opt.lr = lr_schedule(ep, duration)
        episode = task.sample_episode(n_pairs=6, n_queries=6)
        loss, acc = model.forward_episode(episode, train=True)
        train_accs.append(acc)
        train_losses.append(loss)
        if ep % BATCH == 0:
            model.opt.step()
            model.opt.zero_grad()
        if ep % CKPT == 0:
            ho = evaluate(model)
            point = {
                "ep": ep, "lr": float(model.opt.lr), "held_out": ho,
                "train_acc_window": float(np.mean(train_accs[-CKPT:])),
                "train_loss_window": float(np.mean(train_losses[-CKPT:])),
            }
            curve.append(point)
            print(
                f"  [attention seed={seed}] ep {ep:6d}  lr={point['lr']:.5f}  "
                f"loss={point['train_loss_window']:.3f}  "
                f"train={point['train_acc_window']:.3f}  "
                f"held_out={ho:.3f}  ({time.perf_counter()-t0:.0f}s)",
                flush=True,
            )
            partial = dict(config="attention", seed=seed, curve=curve,
                           converged=False, episodes_run=ep, final_acc=ho)
            others = [r for r in all_results
                      if not (r.get("config") == "attention" and r.get("seed") == seed)]
            with open(out_path, "w") as f:
                json.dump(dict(results=others + [partial], summary={}), f, indent=2)
            if check_converged(curve):
                converged = True
                break
    return dict(config="attention", seed=seed, curve=curve, converged=converged,
                final_acc=curve[-1]["held_out"] if curve else None,
                episodes_run=ep)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", nargs="+", type=int, default=DEFAULT_SEEDS)
    parser.add_argument("--duration", type=int, default=DEFAULT_DURATION)
    parser.add_argument("--ceiling", type=int, default=DEFAULT_CEILING)
    parser.add_argument("--out", default="run_attention_long_results.json")
    args = parser.parse_args()

    out_path = args.out
    all_results = []
    if os.path.exists(out_path):
        try:
            prev = json.load(open(out_path))
            all_results = [r for r in prev.get("results", [])
                           if r.get("converged") or r.get("episodes_run", 0) >= args.ceiling]
            print(f"Resuming; done: {[(r['config'], r['seed']) for r in all_results]}")
        except Exception:
            pass

    print(f"AttentionBaseline long run")
    print(f"Seeds: {args.seeds}")
    print(f"Schedule: linear {LR_START} → {LR_END} over {args.duration}")
    print(f"Ceiling: {args.ceiling}\n")

    for seed in args.seeds:
        if any(r["seed"] == seed for r in all_results):
            print(f"Skipping seed={seed}")
            continue
        print(f"\n{'='*72}\nattention seed={seed}\n{'='*72}", flush=True)
        r = run_one(seed, args.duration, args.ceiling, out_path, all_results)
        all_results = [x for x in all_results if x.get("seed") != seed]
        all_results.append(r)
        status = "CONVERGED" if r["converged"] else f"CEILING {args.ceiling}"
        print(f"  -> seed={seed} final_acc={r['final_acc']:.3f} "
              f"eps={r['episodes_run']} {status}", flush=True)
        with open(out_path, "w") as f:
            json.dump(dict(results=all_results, summary={}), f, indent=2)

    finals = np.array([r["final_acc"] for r in all_results])
    summary = dict(
        mean=float(finals.mean()), std=float(finals.std()),
        min=float(finals.min()), max=float(finals.max()),
        n=len(finals),
        per_seed={str(r["seed"]): r["final_acc"] for r in all_results},
    )
    print(f"\nSUMMARY attention mean={summary['mean']:.3f} std={summary['std']:.3f} "
          f"[{summary['min']:.3f}, {summary['max']:.3f}] n={summary['n']}")
    with open(out_path, "w") as f:
        json.dump(dict(args=vars(args), results=all_results, summary=summary), f, indent=2)
    print(f"Saved {out_path}")


if __name__ == "__main__":
    main()
