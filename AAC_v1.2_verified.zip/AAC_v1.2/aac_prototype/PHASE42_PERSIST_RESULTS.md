# Phase 4.2 — Learned / State-Dependent Persistence

**Status: REVISED — "learned persistence helps" does not survive magnitude control or multi-seed**

## Critical control (fixed λ at learned magnitude)

### Seed 0

| config | held-out | λ |
|--------|----------|---|
| fixed_0.999 | 0.676 | 0.999 |
| fixed_0.9999 | **0.861** | 0.9999 |
| fixed_0.99999 | 0.670 | 0.99999 |
| global (learned) | 0.811 | → ~0.9999 |

### Multi-seed (n=3)

| config | seed 0 | seed 1 | seed 2 | **mean** | std |
|--------|--------|--------|--------|----------|-----|
| fixed_0.9999 | 0.861 | 0.652 | 0.651 | **0.721** | 0.099 |
| global | 0.811 | 0.751 | 0.627 | **0.730** | 0.077 |

**Ranges fully overlap.** Mean difference is +0.9 pp for global — not meaningful.

## Revised interpretation

1. Original +13.5 pp (global vs fixed_0.999) was **λ magnitude**, not adaptivity.
2. A fixed constant at 0.9999 matches learned global across seeds.
3. λ=0.999 was underswept; λ=0.99999 is worse (noise accumulation).
4. Learned global λ remains a reasonable *search* procedure that finds ~0.9999 without a grid search — but is not better than that constant once found.

## AttentionBaseline under Phase 4.1-long schedule (related check #4)

| seed | held-out | episodes |
|------|----------|----------|
| 0 | 0.557 | 4500 (converged) |
| 1 | 0.572 | 4000 (converged) |
| 2 | 0.586 | 8000 (converged) |
| **mean** | **0.571 ± 0.012** | |

Attention plateaus ~57% under the long schedule. AAC with λ≈0.9999 reaches 65–86% — the gap is not explained by schedule length alone.

## Pass / fail (revised)

| Criterion | Result |
|-----------|--------|
| Working fixed/global/state implementations | **PASS** |
| "Learned persistence beats fixed" | **FAIL** (magnitude confound + multi-seed tie) |
| Control + multi-seed | **PASS** (done) |

## Files

```
run_phase42_lambda_control.py / results
run_attention_long.py / results
PHASE42_PERSIST_RESULTS.md
```
