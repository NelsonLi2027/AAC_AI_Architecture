# Phase 4.5 — Integrated AAC Evaluation

**Status: PASS with caveat — multi-seed final vs fixed_λ(0.999) stands; fixed_λ magnitude confound from 4.2 applies**

## Canonical stack (`AACDiffFinal`)

utility promotion + global λ + direct write + no matrix reinforce/evict

## Multi-seed results (3 seeds, 8k)

| config | seed 0 | seed 1 | seed 2 | mean | std |
|--------|--------|--------|--------|------|-----|
| final (global λ) | 0.811 | 0.751 | 0.627 | **0.730** | 0.077 |
| fixed_lambda (0.999) | 0.676 | 0.618 | 0.777 | **0.690** | 0.066 |

## Caveats (from priority verification)

1. **Ranges overlap.** final [0.63–0.81] vs fixed_λ [0.62–0.78]. Mean difference
   +4 pp is directionally consistent but **not yet strongly supported** without
   more seeds; seed 2 alone has fixed_λ beating final (0.777 > 0.627).

2. **Phase 4.2 control:** fixed λ=0.9999 (seed 0) reaches **0.861**, beating both
   final and fixed_0.999. Phase 4.5's fixed_lambda used 0.999, so the comparison
   does not show final beats a *well-tuned* fixed constant.

3. **5-seed expansion still PENDING** for all of 4.2–4.5.

## Honest summary

- AAC-final is a working end-to-end stack (utility + persistence + direct write).
- Learned global λ ≈ search for better retention than 0.999; a fixed 0.9999
  may be as good or better (single-seed control).
- Multi-seed mean favors final over fixed_0.999, but variance is large and
  ranges overlap.

## Files

```
run_phase45_integrated.py / results
PHASE45_INTEGRATED_RESULTS.md  (revised)
```
