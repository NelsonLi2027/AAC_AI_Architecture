# Phase 4.4 — Trainable Memory Lifecycle

**Status: PASS with diagnosis — reinforce hurts moderately; reinforce_evict collapses via ||P|| wipe (not explosion)**

## Results (seed 0, 8k)

| mode | held-out | notes |
|------|----------|-------|
| none | **0.811** | baseline |
| reinforce | **0.646** | −16 pp |
| reinforce_evict | **0.020** | chance |

## ||P|| (Frobenius) trajectory — diagnostic

| ep | none ||P|| | reinforce ||P|| | reinforce_evict ||P|| | retain_mean |
|----|-----------|----------------|----------------------|-------------|
| 500 | 1.8 | 2.2 | **0.49** | 0.83 |
| 1500 | 12.0 | 7.8 | **0.16** | 0.89 |
| 2500 | 14.3 | 14.3 | **0.04** | 0.89 |
| 4500 | 14.9 | 15.4 | **0.03** | 0.88 |
| 7500 | 15.1 | 14.1 | **0.03** | 0.87 |

## Diagnosis

1. **reinforce_evict is a memory wipe, not a positive-feedback explosion.**
   ||P|| collapses toward zero (0.49 → 0.03). Opposite of TinyHCASFE RLS blow-up.

2. **Mechanism:** learned retain gate ~0.88 is applied *every timestep* on top of λ.
   Over a sequence of length L, effective retention ≈ (0.88 · λ)^L → near-zero.
   Content never accumulates; training signal dies.

3. **reinforce alone keeps healthy ||P||** (~14–15) but still underperforms none
   by 16 pp — interference from Hebbian boost on dense matrix, not instability.

4. **Trustworthy negative for this formulation:** global per-step soft-evict on a
   dense matrix is the wrong inductive bias. Discrete-slot lifecycle remains open.

## Revised pass/fail

| Criterion | Result |
|-----------|--------|
| Working lifecycle modes | **PASS** |
| ||P|| logged and interpreted | **PASS** |
| reinforce_evict collapse explained | **PASS** (wipe, not blow-up) |
| "learned lifecycle helps" | **FAIL** for these matrix policies |

## Files

```
run_phase44_lifecycle.py / results (mem_norm already in curve)
PHASE44_LIFECYCLE_RESULTS.md  (revised)
```
